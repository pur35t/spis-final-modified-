# SPIS Final — Physical Chess Move Recorder

This Raspberry Pi/OpenCV project watches a fixed physical chessboard, maps its
64 hand-calibrated polygons to chess coordinates, and records each move without
using legality as a gate.

Grid orientation:

- `(0, 0) = a8`
- `(0, 7) = a1`
- `(7, 7) = h1`
- General rule: `(file_index, rank_index) -> abcdefgh[file_index] + (8-rank_index)`

Run `open chess/main.py`. After alignment, make one move, remove your hands
from the camera view, and press Space. The program writes these files after
every detected move:

- `game.pgn` — standard PGN for upload or paste into Chessigma
- `moves_uci.txt` — unconditional raw coordinate moves such as `e2e4`
- `moves.csv` — detailed move and image-change log
- `moves.json` — the same detailed log in JSON form

The raw logs are authoritative: a move is still saved if standard PGN notation
cannot be generated. See `how to run?` for setup and controls.
