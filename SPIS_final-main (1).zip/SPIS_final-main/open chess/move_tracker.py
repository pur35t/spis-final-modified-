"""Square-based physical chess move detection and game logging.

The camera detector never decides whether a move is legal.  It identifies the
source and destination squares from the image change and the tracked physical
piece layout.  Every detected move is written to the raw logs.  A separate,
best-effort python-chess board is used only to produce standard SAN/PGN output.
"""

from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, Mapping, MutableMapping, Sequence, Tuple

import numpy as np


GridKey = Tuple[int, int]
Polygon = Sequence[Tuple[int, int]]


def grid_to_square(grid_key: GridKey) -> str:
    """Map the measured grid orientation to algebraic coordinates.

    The physical calibration uses:
        (0, 0) -> a8
        (0, 7) -> a1
        (7, 7) -> h1
    """

    file_index, rank_index = grid_key
    if not (0 <= file_index < 8 and 0 <= rank_index < 8):
        raise ValueError(f"Grid key outside the 8x8 board: {grid_key}")
    return f"{chr(ord('a') + file_index)}{8 - rank_index}"


def square_to_grid(square: str) -> GridKey:
    """Inverse of :func:`grid_to_square`."""

    if not re.fullmatch(r"[a-h][1-8]", square):
        raise ValueError(f"Invalid chess square: {square!r}")
    return ord(square[0]) - ord("a"), 8 - int(square[1])


def build_grid_map(board_squares: Mapping[GridKey, Polygon]) -> Dict[GridKey, str]:
    """Validate the hard-coded grid and return all 64 algebraic labels."""

    expected = {(file_index, rank_index) for file_index in range(8) for rank_index in range(8)}
    actual = set(board_squares)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise ValueError(f"BOARD_SQUARES must contain exactly 64 squares; missing={missing}, extra={extra}")
    return {grid_key: grid_to_square(grid_key) for grid_key in board_squares}


@dataclass(frozen=True)
class SquareChange:
    grid_key: GridKey
    square: str
    score: float
    changed_ratio: float
    mean_delta: float


@dataclass(frozen=True)
class DetectedMove:
    source: str
    destination: str
    uci: str
    piece: str
    captured_piece: str | None
    changed_squares: Tuple[SquareChange, ...]


class MoveDetectionError(RuntimeError):
    """Raised when the camera change cannot be reduced to one move."""

    def __init__(self, message: str, changes: Iterable[SquareChange] = ()) -> None:
        super().__init__(message)
        self.changes = tuple(changes)


class PhysicalPosition:
    """Piece placement used for source/destination inference, without validation."""

    def __init__(self) -> None:
        self.pieces: MutableMapping[str, str] = {}
        self.turn = "white"
        self.reset()

    def reset(self) -> None:
        self.pieces.clear()
        for file_name, piece in zip("abcdefgh", "rnbqkbnr"):
            self.pieces[file_name + "8"] = piece
            self.pieces[file_name + "7"] = "p"
            self.pieces[file_name + "2"] = "P"
            self.pieces[file_name + "1"] = piece.upper()
        self.turn = "white"

    def piece_at(self, square: str) -> str | None:
        return self.pieces.get(square)

    def belongs_to_turn(self, piece: str | None) -> bool:
        if piece is None:
            return False
        return piece.isupper() if self.turn == "white" else piece.islower()

    def apply(self, source: str, destination: str) -> Tuple[str, str | None]:
        """Apply a detected move without checking whether chess rules allow it."""

        piece = self.pieces.get(source)
        if piece is None:
            raise ValueError(f"No tracked piece is present on {source}")

        captured_piece = self.pieces.get(destination)

        # Physical castling moves both king and rook, although the log stores
        # the king move as required by UCI and PGN.
        if piece.lower() == "k" and source in ("e1", "e8"):
            rook_moves = {
                ("e1", "g1"): ("h1", "f1"),
                ("e1", "c1"): ("a1", "d1"),
                ("e8", "g8"): ("h8", "f8"),
                ("e8", "c8"): ("a8", "d8"),
            }
            rook_move = rook_moves.get((source, destination))
            if rook_move:
                rook_source, rook_destination = rook_move
                rook = self.pieces.pop(rook_source, None)
                if rook is not None:
                    self.pieces[rook_destination] = rook

        # If a pawn moved diagonally to an empty square, remove the en-passant
        # capture square from the tracked physical layout.
        if piece.lower() == "p" and source[0] != destination[0] and captured_piece is None:
            captured_square = destination[0] + source[1]
            captured_piece = self.pieces.pop(captured_square, None)

        self.pieces.pop(source)

        # The camera cannot identify the selected promotion piece yet. Queen is
        # the explicit default so the raw coordinate remains exportable.
        if piece == "P" and destination[1] == "8":
            piece = "Q"
        elif piece == "p" and destination[1] == "1":
            piece = "q"

        self.pieces[destination] = piece
        self.turn = "black" if self.turn == "white" else "white"
        return piece, captured_piece


def score_square_changes(
    before: np.ndarray,
    after: np.ndarray,
    board_squares: Mapping[GridKey, Polygon],
    pixel_threshold: int = 18,
    border_margin: int = 3,
) -> Tuple[SquareChange, ...]:
    """Return a normalized image-change score for every board polygon."""

    try:
        import cv2
    except ImportError as exc:  # pragma: no cover - only happens off the Pi
        raise RuntimeError("OpenCV is required for camera move detection") from exc

    if before.shape != after.shape:
        raise ValueError(f"Frame sizes do not match: {before.shape} vs {after.shape}")

    before_gray = cv2.cvtColor(before, cv2.COLOR_BGR2GRAY) if before.ndim == 3 else before
    after_gray = cv2.cvtColor(after, cv2.COLOR_BGR2GRAY) if after.ndim == 3 else after
    before_gray = cv2.GaussianBlur(before_gray, (5, 5), 0)
    after_gray = cv2.GaussianBlur(after_gray, (5, 5), 0)
    difference = cv2.absdiff(before_gray, after_gray)

    changes = []
    for grid_key, corners in board_squares.items():
        mask = np.zeros(difference.shape, dtype=np.uint8)
        polygon = np.asarray(corners, dtype=np.int32).reshape((-1, 1, 2))
        cv2.fillPoly(mask, [polygon], 255)
        if border_margin > 0:
            kernel_size = 2 * border_margin + 1
            kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
            mask = cv2.erode(mask, kernel, iterations=1)

        values = difference[mask > 0]
        if values.size == 0:
            changed_ratio = 0.0
            mean_delta = 0.0
        else:
            changed = values >= pixel_threshold
            changed_ratio = float(np.mean(changed))
            mean_delta = float(np.mean(values[changed])) if np.any(changed) else 0.0

        # Ratio dominates; mean delta separates similarly sized changes.
        score = changed_ratio * 100.0 + mean_delta / 255.0
        changes.append(
            SquareChange(
                grid_key=grid_key,
                square=grid_to_square(grid_key),
                score=score,
                changed_ratio=changed_ratio,
                mean_delta=mean_delta,
            )
        )

    return tuple(sorted(changes, key=lambda change: change.score, reverse=True))


def detect_move(
    before: np.ndarray,
    after: np.ndarray,
    board_squares: Mapping[GridKey, Polygon],
    position: PhysicalPosition,
    min_changed_ratio: float = 0.035,
    pixel_threshold: int = 18,
    max_candidates: int = 6,
) -> DetectedMove:
    """Detect one physical move without accepting or rejecting it by legality."""

    changes = score_square_changes(
        before,
        after,
        board_squares,
        pixel_threshold=pixel_threshold,
    )
    candidates = [change for change in changes if change.changed_ratio >= min_changed_ratio]
    candidates = candidates[:max_candidates]

    if len(candidates) < 2:
        raise MoveDetectionError(
            "Fewer than two board squares changed enough to identify a move",
            changes[:6],
        )

    sources = [
        change
        for change in candidates
        if position.belongs_to_turn(position.piece_at(change.square))
    ]
    if not sources:
        raise MoveDetectionError(
            f"No changed square contains the tracked {position.turn} piece",
            candidates,
        )

    # Castling changes four squares. If the king and its expected destination
    # both changed, prefer that pair regardless of the rook's larger score.
    castling_pairs = {
        "e1": ("g1", "c1"),
        "e8": ("g8", "c8"),
    }
    changed_names = {change.square for change in candidates}
    for source_change in sources:
        piece = position.piece_at(source_change.square)
        if piece and piece.lower() == "k" and source_change.square in castling_pairs:
            for destination in castling_pairs[source_change.square]:
                if destination in changed_names:
                    destination_change = next(c for c in candidates if c.square == destination)
                    return DetectedMove(
                        source=source_change.square,
                        destination=destination,
                        uci=source_change.square + destination,
                        piece=piece,
                        captured_piece=position.piece_at(destination),
                        changed_squares=tuple(candidates),
                    )

    source_change = sources[0]
    source = source_change.square
    piece = position.piece_at(source)
    destination_candidates = [change for change in candidates if change.square != source]

    # A destination should be empty or contain the other side. This rejects a
    # noisy changed square occupied by another piece belonging to the mover.
    usable_destinations = []
    for change in destination_candidates:
        occupant = position.piece_at(change.square)
        if occupant is None or not position.belongs_to_turn(occupant):
            usable_destinations.append(change)
    if usable_destinations:
        destination_candidates = usable_destinations

    if not destination_candidates:
        raise MoveDetectionError("No destination square could be identified", candidates)

    destination_change = destination_candidates[0]
    destination = destination_change.square
    captured_piece = position.piece_at(destination)
    promotion = ""
    if piece and piece.lower() == "p" and destination[1] in ("1", "8"):
        promotion = "q"

    return DetectedMove(
        source=source,
        destination=destination,
        uci=source + destination + promotion,
        piece=piece or "?",
        captured_piece=captured_piece,
        changed_squares=tuple(candidates),
    )


class GameRecorder:
    """Write raw move records immediately and maintain a Chessigma-ready PGN."""

    def __init__(self, output_root: Path | str, session_name: str) -> None:
        safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", session_name.strip()).strip("_")
        if not safe_name:
            safe_name = datetime.now().strftime("game_%Y%m%d_%H%M%S")

        self.output_dir = Path(output_root) / safe_name
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.rows = []
        self.uci_moves = []
        self.san_moves = []
        self.pgn_synced = True
        self._pgn_board = None
        self._pgn_game = None
        self._pgn_node = None
        self._start_pgn()
        self.write_exports()

    def _start_pgn(self) -> None:
        try:
            import chess
            import chess.pgn
        except ImportError:
            self.pgn_synced = False
            return

        self._chess = chess
        self._pgn_board = chess.Board()
        self._pgn_game = chess.pgn.Game()
        self._pgn_game.headers["Event"] = "Camera-recorded game"
        self._pgn_game.headers["Site"] = "Physical chessboard"
        self._pgn_game.headers["Date"] = datetime.now().strftime("%Y.%m.%d")
        self._pgn_game.headers["Round"] = "-"
        self._pgn_game.headers["White"] = "White"
        self._pgn_game.headers["Black"] = "Black"
        self._pgn_game.headers["Result"] = "*"
        self._pgn_node = self._pgn_game

    def record(self, move: DetectedMove, side: str) -> str:
        """Record a move unconditionally; return SAN or the raw UCI fallback."""

        san = ""
        pgn_status = "not available"
        if self.pgn_synced and self._pgn_board is not None:
            try:
                chess_move = self._chess.Move.from_uci(move.uci)
                san = self._pgn_board.san(chess_move)
                self._pgn_node = self._pgn_node.add_variation(chess_move)
                self._pgn_board.push(chess_move)
                self.san_moves.append(san)
                pgn_status = "converted"
            except (AssertionError, ValueError):
                # This affects only PGN conversion. The physical move remains
                # in every raw export and later moves continue to be recorded.
                self.pgn_synced = False
                pgn_status = "raw move saved; PGN conversion paused"

        self.uci_moves.append(move.uci)
        row = {
            "ply": len(self.uci_moves),
            "move_number": (len(self.uci_moves) + 1) // 2,
            "side": side,
            "source": move.source,
            "destination": move.destination,
            "uci": move.uci,
            "san": san,
            "piece": move.piece,
            "captured_piece": move.captured_piece or "",
            "pgn_status": pgn_status,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "changed_squares": " ".join(
                f"{change.square}:{change.changed_ratio:.3f}" for change in move.changed_squares
            ),
        }
        self.rows.append(row)
        self.write_exports()
        return san or move.uci

    def write_exports(self) -> None:
        """Rewrite all small exports after every move for crash-safe review."""

        (self.output_dir / "moves_uci.txt").write_text(
            " ".join(self.uci_moves) + ("\n" if self.uci_moves else ""),
            encoding="utf-8",
        )

        fieldnames = [
            "ply",
            "move_number",
            "side",
            "source",
            "destination",
            "uci",
            "san",
            "piece",
            "captured_piece",
            "pgn_status",
            "timestamp",
            "changed_squares",
        ]
        with (self.output_dir / "moves.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(self.rows)

        (self.output_dir / "moves.json").write_text(
            json.dumps(self.rows, indent=2),
            encoding="utf-8",
        )

        if self._pgn_game is not None:
            pgn_text = str(self._pgn_game).rstrip() + "\n"
        else:
            pgn_text = (
                "[Event \"Camera-recorded game\"]\n"
                "[Result \"*\"]\n\n"
                "{Install python-chess to generate standard PGN notation.} *\n"
            )
        (self.output_dir / "game.pgn").write_text(pgn_text, encoding="utf-8")

