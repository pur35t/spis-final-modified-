import importlib.util
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np


MODULE_PATH = Path(__file__).with_name("move_tracker.py")
SPEC = importlib.util.spec_from_file_location("move_tracker", MODULE_PATH)
move_tracker = importlib.util.module_from_spec(SPEC)
import sys
sys.modules["move_tracker"] = move_tracker
SPEC.loader.exec_module(move_tracker)


def change(square, ratio):
    return move_tracker.SquareChange(
        grid_key=move_tracker.square_to_grid(square),
        square=square,
        score=ratio * 100,
        changed_ratio=ratio,
        mean_delta=80,
    )


class MoveTrackerTests(unittest.TestCase):
    def test_grid_orientation(self):
        self.assertEqual(move_tracker.grid_to_square((0, 0)), "a8")
        self.assertEqual(move_tracker.grid_to_square((0, 7)), "a1")
        self.assertEqual(move_tracker.grid_to_square((7, 7)), "h1")
        self.assertEqual(move_tracker.square_to_grid("e2"), (4, 6))

    def test_normal_move_detection(self):
        position = move_tracker.PhysicalPosition()
        ranked_changes = (change("e2", 0.42), change("e4", 0.37))
        with patch.object(move_tracker, "score_square_changes", return_value=ranked_changes):
            detected = move_tracker.detect_move(
                np.zeros((1, 1), dtype=np.uint8),
                np.zeros((1, 1), dtype=np.uint8),
                {},
                position,
            )
        self.assertEqual(detected.uci, "e2e4")
        position.apply(detected.source, detected.destination)
        self.assertEqual(position.piece_at("e4"), "P")
        self.assertEqual(position.turn, "black")

    def test_capture_uses_current_side_as_source(self):
        position = move_tracker.PhysicalPosition()
        position.apply("e2", "e4")
        position.apply("d7", "d5")
        ranked_changes = (change("d5", 0.51), change("e4", 0.43))
        with patch.object(move_tracker, "score_square_changes", return_value=ranked_changes):
            detected = move_tracker.detect_move(
                np.zeros((1, 1), dtype=np.uint8),
                np.zeros((1, 1), dtype=np.uint8),
                {},
                position,
            )
        self.assertEqual(detected.uci, "e4d5")
        self.assertEqual(detected.captured_piece, "p")

    def test_castling_prefers_king_move_among_four_changed_squares(self):
        position = move_tracker.PhysicalPosition()
        position.pieces.pop("f1")
        position.pieces.pop("g1")
        ranked_changes = (
            change("h1", 0.60),
            change("f1", 0.55),
            change("e1", 0.48),
            change("g1", 0.44),
        )
        with patch.object(move_tracker, "score_square_changes", return_value=ranked_changes):
            detected = move_tracker.detect_move(
                np.zeros((1, 1), dtype=np.uint8),
                np.zeros((1, 1), dtype=np.uint8),
                {},
                position,
            )
        self.assertEqual(detected.uci, "e1g1")
        position.apply(detected.source, detected.destination)
        self.assertEqual(position.piece_at("g1"), "K")
        self.assertEqual(position.piece_at("f1"), "R")

    def test_raw_exports_are_written_without_pgn_dependency(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(move_tracker.GameRecorder, "_start_pgn", lambda self: None):
                recorder = move_tracker.GameRecorder(directory, "test game")
                recorder.pgn_synced = False
                detected = move_tracker.DetectedMove(
                    source="e2",
                    destination="e4",
                    uci="e2e4",
                    piece="P",
                    captured_piece=None,
                    changed_squares=(change("e2", 0.4), change("e4", 0.35)),
                )
                recorder.record(detected, "white")
                output = Path(directory) / "test_game"
                self.assertEqual((output / "moves_uci.txt").read_text(), "e2e4\n")
                self.assertIn("e2e4", (output / "moves.csv").read_text())
                self.assertIn('"uci": "e2e4"', (output / "moves.json").read_text())


if __name__ == "__main__":
    unittest.main()
